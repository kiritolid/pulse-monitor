#include "../Source/Hardware.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
    char model[256], arch[256], missing[32];
    assert(pulse_read_string("hw.model", model, sizeof(model)));
    assert(model[0]);
    assert(pulse_read_int("hw.physicalcpu") > 0);
    assert(!pulse_read_string("pulse.nonexistent", missing, sizeof(missing)));
    assert(missing[0] == 0);
    pulse_architecture(arch, sizeof(arch)); assert(arch[0]);
    pulse_architecture(NULL, 0);
    puts("PASS: hardware detection and unavailable values");
}
