# Pulse 2

Application native pour Mac Apple Silicon (macOS 14 ou ultérieur), avec une interface claire inspirée des captures de référence : navigation latérale violette, jauges, panneaux de détails et graphiques remplis.

## Utilisation

Ouvrez **Pulse.app**. Vous pouvez la déplacer dans Applications. L’icône de courbe de la barre de menus permet de rouvrir la fenêtre. Le bouton d’alimentation ou « Quitter Pulse » arrête l’application. Aucun démarrage automatique n’est configuré.

- Tableau de bord : informations du Mac et raccourcis CPU, RAM et GPU.
- Processeur : utilisation système/utilisateur, historique, charge par cœur, charge moyenne et principaux processus.
- GPU : utilisation totale, rendu, Tiler et mémoire partagée, selon les compteurs du pilote.
- RAM : mémoire utilisée, résidente et compressée, swap et principaux processus.
- Disque : occupation du volume système et débits cumulés de tous les disques physiques.
- Réseau : débits des interfaces physiques `en*`, état du lien local et adresses IPv4 locales. Pas de requête Internet ni de test de latence.
- Batterie : charge et source d’alimentation.
- Capteurs : état thermique fourni par macOS.
- Horloge : date et heure du fuseau local.

Le bouton violet en haut suspend ou reprend les mesures. L’engrenage règle l’actualisation à 1, 2 ou 5 secondes. Les processus sont lus toutes les 5 secondes en arrière-plan.

## Interprétation et limites

L’historique couvre les 10 dernières minutes de l’exécution et se remplit progressivement. Aucun historique fictif n’est fourni. Il est effacé lorsque l’application quitte.

La RAM utilisée est une estimation hors cache de fichiers. La mémoire des processus est la mémoire résidente (`ps rss`), différente de l’empreinte mémoire du Moniteur d’activité. Le CPU par processus est la moyenne fournie par `ps`, avec 100 % correspondant à un cœur ; il peut dépasser 100 %. Les mesures globales CPU sont calculées entre deux échantillons.

Les unités Go, Mo et Ko sont en base 1024. Le libre APFS exclut l’espace purgeable. Les compteurs disque représentent tous les disques physiques depuis le démarrage, tandis que la jauge représente le volume contenant le dossier utilisateur.

Les FPS globaux, l’ANE, le GPU par processus, les fréquences instantanées, les températures détaillées, les ventilateurs et SMART ne sont pas collectés dans cette version. Ils sont indiqués comme indisponibles. Les fonctions Bluetooth et Remote des captures ne sont pas implémentées.

Toutes les mesures restent locales. Aucun compte, service privilégié ou accès réseau n’est requis.

## Sources et compilation

`Source/` contient le code Swift. Exécutez `Construire.command` pour recompiler avec les outils de ligne de commande Xcode installés. L’application utilise une signature locale ad hoc, sans notarisation Apple, destinée à ce Mac.

Test des collecteurs : `Pulse.app/Contents/MacOS/Pulse --self-test`.
