#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build Pulse.app/Contents/MacOS Pulse.app/Contents/Resources
for arch in arm64 x86_64; do
  xcrun clang -O2 -target "$arch-apple-macos14.0" -c Source/Hardware.c -o "build/Hardware-$arch.o"
  xcrun swiftc -O -parse-as-library -target "$arch-apple-macos14.0" -import-objc-header Source/Hardware.h Source/*.swift "build/Hardware-$arch.o" -o "build/Pulse-$arch" -framework SwiftUI -framework AppKit -framework IOKit
done
lipo -create build/Pulse-arm64 build/Pulse-x86_64 -output Pulse.app/Contents/MacOS/Pulse
cp Resources/report.js Pulse.app/Contents/Resources/report.js
cp Resources/Info.plist Pulse.app/Contents/Info.plist
cp Resources/AppIcon.icns Pulse.app/Contents/Resources/AppIcon.icns
xattr -cr Pulse.app
codesign --force --deep --sign - Pulse.app
printf 'Pulse compilé pour Apple Silicon et Intel.\n'
