import Foundation
import AppKit
import IOKit
import IOKit.ps
import Darwin

struct ExtraMetrics {
    var renderer: Double?, tiler: Double?, gpuMemory: Double?, gpuCores: Int?
    var diskTotal = 0.0, diskFree = 0.0
    var diskName = "Volume système"
    var diskRead: Double?, diskWrite: Double?
    var totalRead = 0.0, totalWrite = 0.0
    var download: Double?, upload: Double?
    var interfaces: [String] = []
    var addresses: [String] = []
    var networkUp = false
    var battery: Double?
    var charging = false
    var powerSource = "Secteur"
    var load: [Double] = [0, 0, 0]
}
struct ProcessRow: Identifiable {
    let id: Int
    let name: String
    let cpu: Double
    let memory: Double
}
func sysString(_ key: String) -> String {
    var buffer = [CChar](repeating: 0, count: 1024)
    return pulse_read_string(key, &buffer, buffer.count) != 0 ? String(cString: buffer) : "Indisponible"
}
func sysInt(_ key: String) -> Int { Int(pulse_read_int(key)) }
func rate(_ value: Double?) -> String {
    guard let value else { return "—" }
    return value >= 1_048_576 ? String(format: "%.1f Mo/s", value / 1_048_576) : String(format: "%.0f Ko/s", value / 1024)
}
func bytes(_ value: Double) -> String {
    value >= 1_073_741_824 ? gb(value) : String(format: "%.0f Mo", value / 1_048_576)
}

extension Monitor {
    func readBattery() {
        extra.battery = nil
        guard let blob = IOPSCopyPowerSourcesInfo()?.takeRetainedValue(),
              let list = IOPSCopyPowerSourcesList(blob)?.takeRetainedValue() as? [CFTypeRef] else { return }
        for source in list {
            guard let desc = IOPSGetPowerSourceDescription(blob, source)?.takeUnretainedValue() as? [String: Any],
                  let capacity = desc[kIOPSCurrentCapacityKey] as? NSNumber,
                  let maxCapacity = desc[kIOPSMaxCapacityKey] as? NSNumber, maxCapacity.doubleValue > 0 else { continue }
            extra.battery = capacity.doubleValue / maxCapacity.doubleValue * 100
            extra.charging = desc[kIOPSIsChargingKey] as? Bool ?? false
            extra.powerSource = (desc[kIOPSPowerSourceStateKey] as? String) == kIOPSACPowerValue ? "Secteur" : "Batterie"
            break
        }
    }
}
