#include "Hardware.h"
#include <sys/sysctl.h>
#include <sys/utsname.h>
#include <string.h>
int pulse_read_string(const char *key, char *out, size_t capacity) {
    if (!key || !out || capacity == 0) return 0;
    out[0] = 0;
    size_t size = capacity;
    if (sysctlbyname(key, out, &size, NULL, 0) != 0) return 0;
    out[capacity - 1] = 0;
    return 1;
}
int pulse_read_int(const char *key) {
    int value = 0; size_t size = sizeof(value);
    return sysctlbyname(key, &value, &size, NULL, 0) == 0 ? value : 0;
}
void pulse_architecture(char *out, size_t capacity) {
    if (!out || !capacity) return;
    struct utsname info;
    const char *name = pulse_read_int("hw.optional.arm64") ? "Apple Silicon · ARM64" :
        (uname(&info) == 0 ? info.machine : "Architecture inconnue");
    strlcpy(out, name, capacity);
}
