#ifndef PULSE_HARDWARE_H
#define PULSE_HARDWARE_H
#include <stddef.h>
int pulse_read_string(const char *key, char *out, size_t capacity);
int pulse_read_int(const char *key);
void pulse_architecture(char *out, size_t capacity);
#endif
