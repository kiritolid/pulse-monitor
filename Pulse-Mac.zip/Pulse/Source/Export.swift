import SwiftUI
import UniformTypeIdentifiers

struct Hardware {
    static let architecture: String = {
        var buffer = [CChar](repeating: 0, count: 256)
        pulse_architecture(&buffer, buffer.count)
        return String(cString: buffer)
    }()
    static let coreDescription: String = {
        var result = "\(ProcessInfo.processInfo.processorCount) cœurs logiques"
        let efficiency = sysInt("hw.perflevel1.physicalcpu")
        let performance = sysInt("hw.perflevel0.physicalcpu")
        if efficiency > 0 { result += "\n\(efficiency) cœurs à haute efficacité énergétique" }
        if performance > 0 { result += "\n\(performance) cœurs de performance" }
        return result
    }()
}
extension Monitor {
    func exportReport() {
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.html]
        panel.nameFieldStringValue = "Pulse-rapport.html"
        panel.title = "Exporter le rapport interactif"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            let rows: [[String: Any]] = history.map { sample in
                ["time": sample.time.timeIntervalSince1970 * 1000, "cpu": sample.cpu as Any? ?? NSNull(), "ram": sample.ram as Any? ?? NSNull(), "gpu": sample.gpu as Any? ?? NSNull()]
            }
            let payload: [String: Any] = ["cpu": cpuName, "model": sysString("hw.model"), "architecture": Hardware.architecture, "memory": gb(total), "samples": rows]
            let data = try JSONSerialization.data(withJSONObject: payload)
            guard let resource = Bundle.main.url(forResource: "report", withExtension: "js") else { throw CocoaError(.fileNoSuchFile) }
            let js = try String(contentsOf: resource, encoding: .utf8)
            let html = """
            <!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Pulse — Rapport</title>
            <style>body{font:15px system-ui;background:#f5f3f8;color:#222;margin:40px auto;max-width:1080px;padding:20px}h1{color:#883b91;font-size:36px}.card{background:white;border-radius:18px;padding:24px;margin:20px 0}button,select{font:inherit;padding:10px;border-radius:8px;border:1px solid #ddd}canvas{width:100%;height:300px}#tooltip{min-height:24px;color:#883b91}p{line-height:1.6}</style>
            <h1>Pulse <small>Rapport système</small></h1><p id="specs"></p><div class="card"><label>Mesure <select id="metric"><option value="cpu">Processeur</option><option value="ram">RAM</option><option value="gpu">GPU</option></select></label> <button id="csv">Exporter CSV</button><p id="summary"></p><canvas id="chart"></canvas><p id="tooltip">Survole la courbe pour explorer les mesures.</p></div><p>Rapport local · Aucune connexion réseau · Les données manquantes restent vides.</p>
            <script>const payload = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob('\(data.base64EncodedString())'), c => c.charCodeAt(0))));</script><script>\(js)</script></html>
            """
            try html.write(to: url, atomically: true, encoding: .utf8)
            NSWorkspace.shared.open(url)
        } catch { let alert = NSAlert(error: error); alert.runModal() }
    }
}
