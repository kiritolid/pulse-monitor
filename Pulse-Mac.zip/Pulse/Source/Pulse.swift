import SwiftUI
import AppKit
import IOKit
import IOKit.ps
import Darwin

struct Sample: Identifiable {
    let id = UUID()
    let time = Date()
    let cpu: Double?
    let ram: Double?
    let gpu: Double?
    var renderer: Double? = nil
    var tiler: Double? = nil
    var swap: Double? = nil
    var read: Double? = nil
    var write: Double? = nil
    var download: Double? = nil
    var upload: Double? = nil
}

final class Monitor: ObservableObject {
    @Published var extra = ExtraMetrics()
    @Published var processes: [ProcessRow] = []
    @Published var cpuSystem: Double = 0
    @Published var cpuUser: Double = 0
    private var lastExtras = ProcessInfo.processInfo.systemUptime
    private var previousDisk: (Double, Double)?
    private var previousNetwork: [String: (UInt32, UInt32)] = [:]
    private var processPending = false
    private var lastProcesses = Date.distantPast
    @Published var cpu: Double?
    @Published var gpu: Double?
    @Published var ram: Double?
    @Published var used: Double = 0
    @Published var compressed: Double = 0
    @Published var wired: Double = 0
    @Published var swap: Double = 0
    @Published var history: [Sample] = []
    @Published var cores: [Double] = []
    @Published var paused = false
    @Published var interval = 1.0 { didSet { startTimer() } }
    let total = Double(ProcessInfo.processInfo.physicalMemory)
    let cpuName: String
    var gpuName = "GPU"
    private var previous: [UInt32] = []
    private var timer: Timer?
    private let host = mach_host_self()
    init() {
        var size = 0
        sysctlbyname("machdep.cpu.brand_string", nil, &size, nil, 0)
        var name = [CChar](repeating: 0, count: max(size, 1))
        sysctlbyname("machdep.cpu.brand_string", &name, &size, nil, 0)
        cpuName = String(cString: name)
        sample()
        startTimer()
    }
    func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { [weak self] _ in
            guard let self, !self.paused else { return }
            self.sample()
        }
        timer?.tolerance = interval * 0.15
    }
    func readCPU() -> Double? {
        var count: natural_t = 0
        var info: processor_info_array_t?
        var infoCount: mach_msg_type_number_t = 0
        guard host_processor_info(host, PROCESSOR_CPU_LOAD_INFO, &count, &info, &infoCount) == KERN_SUCCESS, let info else { return nil }
        defer { vm_deallocate(mach_task_self_, vm_address_t(UInt(bitPattern: info)), vm_size_t(Int(infoCount) * MemoryLayout<integer_t>.stride)) }
        let current = (0..<Int(infoCount)).map { UInt32(bitPattern: info[$0]) }
        defer { previous = current }
        guard previous.count == current.count else { return nil }
        var busyTotal = 0.0, allTotal = 0.0, systemTotal = 0.0, userTotal = 0.0
        var values: [Double] = []
        for c in 0..<Int(count) {
            let base = c * Int(CPU_STATE_MAX)
            let deltas = (0..<Int(CPU_STATE_MAX)).map { Double(current[base + $0] &- previous[base + $0]) }
            let all = deltas.reduce(0, +)
            let busy = all - deltas[Int(CPU_STATE_IDLE)]
            values.append(all > 0 ? busy / all * 100 : 0)
            busyTotal += busy; allTotal += all
            systemTotal += deltas[Int(CPU_STATE_SYSTEM)]
            userTotal += deltas[Int(CPU_STATE_USER)] + deltas[Int(CPU_STATE_NICE)]
        }
        cpuSystem = allTotal > 0 ? systemTotal / allTotal * 100 : 0
        cpuUser = allTotal > 0 ? userTotal / allTotal * 100 : 0
        cores = values
        return allTotal > 0 ? busyTotal / allTotal * 100 : 0
    }
    func readMemory() -> Double? {
        var vm = vm_statistics64_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<vm_statistics64_data_t>.size / MemoryLayout<integer_t>.size)
        let result = withUnsafeMutablePointer(to: &vm) { ptr in
            ptr.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { host_statistics64(host, HOST_VM_INFO64, $0, &count) }
        }
        guard result == KERN_SUCCESS else { return nil }
        var pageSize: vm_size_t = 0
        host_page_size(host, &pageSize)
        let page = Double(pageSize)
        wired = Double(vm.wire_count) * page
        compressed = Double(vm.compressor_page_count) * page
        // Active + inactive include file-backed cache: exclude external pages.
        let appPages = max(0, Double(vm.active_count) + Double(vm.inactive_count) - Double(vm.external_page_count))
        used = min(total, appPages * page + wired + compressed)
        var usage = xsw_usage()
        var size = MemoryLayout<xsw_usage>.size
        if sysctlbyname("vm.swapusage", &usage, &size, nil, 0) == 0 { swap = Double(usage.xsu_used) }
        return used / total * 100
    }
    func readGPU() -> Double? {
        var iterator: io_iterator_t = 0
        guard IOServiceGetMatchingServices(kIOMainPortDefault, IOServiceMatching("IOAccelerator"), &iterator) == KERN_SUCCESS else { return nil }
        defer { IOObjectRelease(iterator) }
        extra.renderer = nil; extra.tiler = nil
        var values: [Double] = []
        while true {
            let entry = IOIteratorNext(iterator)
            if entry == 0 { break }
            defer { IOObjectRelease(entry) }
            if let model = IORegistryEntryCreateCFProperty(entry, "model" as CFString, kCFAllocatorDefault, 0)?.takeRetainedValue() as? String { gpuName = model }
            if let stats = IORegistryEntryCreateCFProperty(entry, "PerformanceStatistics" as CFString, kCFAllocatorDefault, 0)?.takeRetainedValue() as? [String: Any],
               let utilization = stats["Device Utilization %"] as? NSNumber {
                values.append(min(100, max(0, utilization.doubleValue)))
                extra.renderer = (stats["Renderer Utilization %"] as? NSNumber)?.doubleValue
                extra.tiler = (stats["Tiler Utilization %"] as? NSNumber)?.doubleValue
                extra.gpuMemory = (stats["In use system memory"] as? NSNumber)?.doubleValue
                extra.gpuCores = (IORegistryEntryCreateCFProperty(entry, "gpu-core-count" as CFString, kCFAllocatorDefault, 0)?.takeRetainedValue() as? NSNumber)?.intValue
            }
        }
        return values.max()
    }
    func sample() {
        cpu = readCPU(); ram = readMemory(); gpu = readGPU()
        readExtras()
        refreshProcesses()
        history.append(Sample(cpu: cpu, ram: ram, gpu: gpu, renderer: extra.renderer, tiler: extra.tiler, swap: swap, read: extra.diskRead, write: extra.diskWrite, download: extra.download, upload: extra.upload))
        let cutoff = Date().addingTimeInterval(-600)
        history.removeAll { $0.time < cutoff }
    }
    func togglePause() {
        paused.toggle()
        if !paused { previous = []; previousDisk = nil; previousNetwork = [:]; sample() }
    }
}

func percent(_ value: Double?) -> String { value.map { String(format: "%.0f", $0) } ?? "—" }
func gb(_ bytes: Double) -> String { String(format: "%.1f Go", bytes / 1_073_741_824) }
let mint = Color(red: 0.16, green: 0.72, blue: 0.42)
let violet = Color(red: 0.55, green: 0.22, blue: 0.58)
let blue = Color(red: 0, green: 0.53, blue: 1)

struct MenuPanel: View {
    @ObservedObject var monitor: Monitor
    @Environment(\.openWindow) var openWindow
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Pulse").font(.title2.bold())
            HStack { Text("CPU"); Spacer(); Text("\(percent(monitor.cpu)) %").foregroundStyle(mint) }
            HStack { Text("RAM"); Spacer(); Text("\(gb(monitor.used)) / \(gb(monitor.total))").foregroundStyle(violet) }
            HStack { Text("GPU"); Spacer(); Text("\(percent(monitor.gpu)) %").foregroundStyle(blue) }
            Divider()
            Button("Ouvrir le tableau de bord") { openWindow(id: "dashboard"); NSApp.activate(ignoringOtherApps: true) }
            Button(monitor.paused ? "Reprendre les mesures" : "Mettre en pause") { monitor.togglePause() }
            Button("Quitter Pulse") { NSApp.terminate(nil) }.keyboardShortcut("q")
        }.padding(20).frame(width: 290).preferredColorScheme(.light)
    }
}

@main struct PulseApp: App {
    @StateObject private var monitor = Monitor()
    init() {
        if CommandLine.arguments.contains("--self-test") {
            let m = Monitor()
            Thread.sleep(forTimeInterval: 0.3)
            m.sample()
            let valid = m.cpu != nil && m.ram != nil && (0...100).contains(m.cpu!) && (0...100).contains(m.ram!)
            print("CPU: \(percent(m.cpu))%, RAM: \(gb(m.used))/\(gb(m.total)), GPU: \(percent(m.gpu))%, cœurs: \(m.cores.count)")
            let extraValid = m.extra.diskTotal > 0 && m.extra.diskFree >= 0 && m.extra.diskFree <= m.extra.diskTotal && m.extra.diskRead != nil && m.extra.download != nil
            print("Disque: \(gb(m.extra.diskTotal)), lecture: \(rate(m.extra.diskRead)), réseau: \(rate(m.extra.download)), batterie: \(percent(m.extra.battery))%")
            m.togglePause()
            let pauseValid = m.paused
            m.togglePause()
            let resumeValid = !m.paused && m.cpu == nil && m.extra.diskRead == nil && m.extra.download == nil
            let passed = valid && extraValid && pauseValid && resumeValid
            print(passed ? "PASS — CPU, RAM, disque, réseau, pause et reprise" : "FAIL")
            exit(passed ? 0 : 1)
        }
    }
    var body: some Scene {
        Window("Pulse — Moniteur système", id: "dashboard") { Dashboard(monitor: monitor) }.defaultSize(width: 1180, height: 800)
        MenuBarExtra { MenuPanel(monitor: monitor) } label: { Image(systemName: "waveform.path.ecg"); Text("\(percent(monitor.cpu)) %") }.menuBarExtraStyle(.window)
    }
}

extension Monitor {
    func readExtras() {
        let now = ProcessInfo.processInfo.systemUptime
        let elapsed = max(0.001, now - lastExtras)
        defer { lastExtras = now }
        if let values = try? URL(fileURLWithPath: NSHomeDirectory()).resourceValues(forKeys: [.volumeTotalCapacityKey, .volumeAvailableCapacityKey, .volumeNameKey]) {
            extra.diskTotal = Double(values.volumeTotalCapacity ?? 0)
            extra.diskFree = Double(values.volumeAvailableCapacity ?? 0)
            extra.diskName = values.volumeName ?? "Volume système"
        }
        var iterator: io_iterator_t = 0
        var read = 0.0, write = 0.0, found = false
        if IOServiceGetMatchingServices(kIOMainPortDefault, IOServiceMatching("IOBlockStorageDriver"), &iterator) == KERN_SUCCESS {
            while true {
                let service = IOIteratorNext(iterator); if service == 0 { break }
                if let stats = IORegistryEntryCreateCFProperty(service, "Statistics" as CFString, kCFAllocatorDefault, 0)?.takeRetainedValue() as? [String: Any],
                   let r = stats["Bytes (Read)"] as? NSNumber, let w = stats["Bytes (Write)"] as? NSNumber {
                    read += r.doubleValue; write += w.doubleValue; found = true
                }
                IOObjectRelease(service)
            }
            IOObjectRelease(iterator)
        }
        extra.diskRead = nil; extra.diskWrite = nil
        if found {
            if let prior = previousDisk, read >= prior.0, write >= prior.1 {
                extra.diskRead = (read - prior.0) / elapsed; extra.diskWrite = (write - prior.1) / elapsed
            }
            previousDisk = (read, write); extra.totalRead = read; extra.totalWrite = write
        } else { previousDisk = nil }
        var head: UnsafeMutablePointer<ifaddrs>?
        extra.interfaces = []; extra.addresses = []; extra.networkUp = false
        var downloaded = 0.0, uploaded = 0.0, hasDelta = false
        var nextNetwork: [String: (UInt32, UInt32)] = [:]
        if getifaddrs(&head) == 0 {
            var pointer = head
            while let current = pointer {
                let item = current.pointee; pointer = item.ifa_next
                let name = String(cString: item.ifa_name)
                guard name.hasPrefix("en"), let address = item.ifa_addr else { continue }
                if Int32(address.pointee.sa_family) == AF_LINK, let data = item.ifa_data {
                    let stats = data.assumingMemoryBound(to: if_data.self).pointee
                    nextNetwork[name] = (stats.ifi_ibytes, stats.ifi_obytes)
                    if let prior = previousNetwork[name] {
                        downloaded += Double(stats.ifi_ibytes &- prior.0) / elapsed
                        uploaded += Double(stats.ifi_obytes &- prior.1) / elapsed
                        hasDelta = true
                    }
                    if item.ifa_flags & UInt32(IFF_UP) != 0 && item.ifa_flags & UInt32(IFF_RUNNING) != 0 {
                        extra.interfaces.append(name); extra.networkUp = true
                    }
                }
                if Int32(address.pointee.sa_family) == AF_INET {
                    var buffer = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                    if getnameinfo(address, socklen_t(address.pointee.sa_len), &buffer, socklen_t(buffer.count), nil, 0, NI_NUMERICHOST) == 0 { extra.addresses.append("\(name) : \(String(cString: buffer))") }
                }
            }
            freeifaddrs(head)
        }
        previousNetwork = nextNetwork
        extra.download = hasDelta ? downloaded : nil; extra.upload = hasDelta ? uploaded : nil
        getloadavg(&extra.load, 3)
        readBattery()
    }
    func refreshProcesses() {
        guard !processPending, Date().timeIntervalSince(lastProcesses) >= 5 else { return }
        processPending = true; lastProcesses = Date()
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let process = Process(); let pipe = Pipe()
            process.executableURL = URL(fileURLWithPath: "/bin/ps")
            process.arguments = ["-axo", "pid=,pcpu=,rss=,comm="]
            process.standardOutput = pipe; process.standardError = FileHandle.nullDevice
            var rows: [ProcessRow] = []
            do {
                try process.run()
                let data = pipe.fileHandleForReading.readDataToEndOfFile(); process.waitUntilExit()
                for line in (String(data: data, encoding: .utf8) ?? "").split(separator: "\n") {
                    let parts = line.split(maxSplits: 3, omittingEmptySubsequences: true, whereSeparator: { $0.isWhitespace })
                    if parts.count == 4, let pid = Int(parts[0]), let cpu = Double(parts[1]), let memory = Double(parts[2]) {
                        rows.append(ProcessRow(id: pid, name: URL(fileURLWithPath: String(parts[3])).lastPathComponent, cpu: cpu, memory: memory * 1024))
                    }
                }
            } catch { }
            let result = rows
            DispatchQueue.main.async { self?.processes = result; self?.processPending = false }
        }
    }
}
