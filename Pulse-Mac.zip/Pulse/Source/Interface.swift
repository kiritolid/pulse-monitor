import SwiftUI
import AppKit

private let panelColor = Color(nsColor: .controlBackgroundColor)
private let trackColor = Color.primary.opacity(0.09)
enum Page: String, CaseIterable {
    case overview = "Tableau de bord", cpu = "Processeur", gpu = "GPU", ram = "RAM", disk = "Disque", sensors = "Capteurs", network = "Réseau", battery = "Batterie", clock = "Horloge"
    var icon: String {
        switch self {
        case .overview: return "square.grid.3x3.fill"
        case .cpu: return "cpu"
        case .gpu: return "display"
        case .ram: return "memorychip"
        case .disk: return "internaldrive"
        case .sensors: return "fanblades.fill"
        case .network: return "network"
        case .battery: return "battery.100"
        case .clock: return "clock.fill"
        }
    }
}
struct Panel<Content: View>: View {
    @ViewBuilder let content: Content
    var body: some View { content.padding(16).frame(maxWidth: .infinity, alignment: .leading).background(panelColor, in: RoundedRectangle(cornerRadius: 12)) }
}
struct Block<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 9) { Text(title).font(.system(size: 14, weight: .semibold)).padding(.leading, 4); content }
    }
}
struct InfoRow: View {
    let label: String
    let value: String
    var color: Color? = nil
    var body: some View {
        HStack(alignment: .top, spacing: 5) {
            if let color { RoundedRectangle(cornerRadius: 2).fill(color).frame(width: 10, height: 10).padding(.top, 3) }
            Text(label).foregroundStyle(.secondary)
            Spacer(minLength: 15)
            Text(value).multilineTextAlignment(.trailing).monospacedDigit().textSelection(.enabled)
        }.font(.system(size: 13)).frame(minHeight: 22)
    }
}
struct UsageBar: View {
    var pieces: [(Double, Color)]
    var body: some View {
        GeometryReader { geometry in
            HStack(spacing: 0) {
                ForEach(pieces.indices, id: \.self) { i in pieces[i].1.frame(width: geometry.size.width * min(100, max(0, pieces[i].0)) / 100) }
                Spacer(minLength: 0)
            }.background(trackColor).clipShape(RoundedRectangle(cornerRadius: 3))
        }.frame(height: 9)
    }
}
struct Ring: View {
    var value: Double?
    var color: Color = blue
    var body: some View {
        ZStack {
            Circle().stroke(trackColor, lineWidth: 8)
            Circle().trim(from: 0, to: min(1, max(0, (value ?? 0) / 100))).stroke(color, style: StrokeStyle(lineWidth: 8, lineCap: .round)).rotationEffect(.degrees(-90))
            Text("\(percent(value))%" ).font(.system(size: 21, weight: .medium)).monospacedDigit()
        }.frame(width: 82, height: 82).padding(6)
    }
}
struct Meter: View {
    let title: String
    let value: Double?
    var color: Color = violet
    var body: some View {
        VStack(spacing: 4) { HStack { Text(title).foregroundStyle(.secondary); Spacer(); Text(value == nil ? "Indisponible" : "\(percent(value)) %").monospacedDigit() }.font(.system(size: 12)); UsageBar(pieces: [(value ?? 0, color)]) }
    }
}

final class ChartHover: ObservableObject { @Published var fraction: Double? }
struct HistoryChart: View {
    @StateObject private var hover = ChartHover()
    let samples: [Sample]
    let key: KeyPath<Sample, Double?>
    var color: Color = violet
    var scale: Double = 100
    var percentAxis = true
    var height: CGFloat = 150
    var body: some View {
        Panel {
            VStack(spacing: 6) {
                HStack(spacing: 8) {
                    VStack { Text(percentAxis ? "100%" : rate(scale)); Spacer(); Text(percentAxis ? "50%" : ""); Spacer(); Text(percentAxis ? "0%" : "0") }.font(.system(size: 10)).foregroundStyle(.secondary).frame(width: percentAxis ? 32 : 65, alignment: .leading)
                    Canvas { context, size in
                        for i in 0...4 {
                            let y = size.height * Double(i) / 4
                            var path = Path(); path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y))
                            context.stroke(path, with: .color(.black.opacity(0.045)), lineWidth: 0.5)
                        }
                        guard let last = samples.last else { return }
                        var points: [CGPoint] = []
                        func drawSegment(_ points: [CGPoint]) {
                            guard let first = points.first, let end = points.last else { return }
                            var line = Path(); line.move(to: first)
                            for point in points.dropFirst() { line.addLine(to: point) }
                            var fill = line
                            fill.addLine(to: CGPoint(x: end.x, y: size.height)); fill.addLine(to: CGPoint(x: first.x, y: size.height)); fill.closeSubpath()
                            context.fill(fill, with: .linearGradient(Gradient(colors: [color.opacity(0.9), color.opacity(0.4)]), startPoint: .zero, endPoint: CGPoint(x: 0, y: size.height)))
                            context.stroke(line, with: .color(color), lineWidth: 1)
                        }
                        for sample in samples {
                            guard let value = sample[keyPath: key] else { drawSegment(points); points = []; continue }
                            let x = size.width * max(0, 1 + sample.time.timeIntervalSince(last.time) / 600)
                            let y = size.height * (1 - min(1, max(0, value / max(1, scale))))
                            points.append(CGPoint(x: x, y: y))
                        }
                        drawSegment(points)
                    }
                }.frame(height: height)
                .onContinuousHover { phase in
                    switch phase { case .active(let location): hover.fraction = location.x; case .ended: hover.fraction = nil }
                }
                .overlay(alignment: .topTrailing) {
                    GeometryReader { geo in
                        if let x = hover.fraction, let last = samples.last {
                            let fraction = min(1, max(0, (x - (percentAxis ? 40 : 73)) / max(1, geo.size.width - (percentAxis ? 40 : 73))))
                            let date = last.time.addingTimeInterval((fraction - 1) * 600)
                            if let nearest = samples.min(by: { abs($0.time.timeIntervalSince(date)) < abs($1.time.timeIntervalSince(date)) }), abs(nearest.time.timeIntervalSince(date)) < 10 {
                                Text("\(nearest.time.formatted(date: .omitted, time: .standard)) · \(nearest[keyPath: key].map { percentAxis ? String(format: "%.1f %%", $0) : rate($0) } ?? "Indisponible")")
                                    .font(.caption.monospacedDigit()).padding(8).background(.regularMaterial, in: RoundedRectangle(cornerRadius: 8)).frame(maxWidth: .infinity, alignment: .trailing)
                            }
                        }
                    }.allowsHitTesting(false)
                }
                HStack {
                    ForEach(0..<5) { index in
                        if index > 0 { Spacer() }
                        Text((samples.last?.time ?? Date()).addingTimeInterval(Double(index - 4) * 150), format: .dateTime.hour().minute().second())
                    }
                }.font(.system(size: 10)).foregroundStyle(.secondary)
            }
        }
    }
}
struct ProcessTable: View {
    @ObservedObject var monitor: Monitor
    var memory = false
    var rows: [ProcessRow] { Array(monitor.processes.sorted { memory ? $0.memory > $1.memory : $0.cpu > $1.cpu }.prefix(8)) }
    var body: some View {
        Block(title: "Processus principaux") {
            Panel {
                VStack(spacing: 0) {
                    HStack { Text("Processus").frame(maxWidth: .infinity, alignment: .leading); Text("PID").frame(width: 60, alignment: .leading); Text(memory ? "Mémoire résidente" : "CPU · 100 % = un cœur").frame(maxWidth: .infinity, alignment: .trailing) }.font(.system(size: 11)).foregroundStyle(.secondary).padding(8)
                    ForEach(Array(rows.enumerated()), id: \.element.id) { index, row in
                        HStack(spacing: 10) {
                            Image(systemName: "app.fill").foregroundStyle(.gray).frame(width: 20)
                            Text(row.name).lineLimit(1).frame(maxWidth: .infinity, alignment: .leading)
                            Text("\(row.id)").foregroundStyle(.secondary).frame(width: 60, alignment: .leading)
                            UsageBar(pieces: [(memory ? row.memory / monitor.total * 100 : min(100, row.cpu), violet)]).frame(maxWidth: .infinity)
                            Text(memory ? bytes(row.memory) : String(format: "%.1f %%", row.cpu)).monospacedDigit().frame(width: 80, alignment: .trailing)
                        }.font(.system(size: 12)).padding(8).background(index.isMultiple(of: 2) ? Color.black.opacity(0.018) : .clear, in: RoundedRectangle(cornerRadius: 4))
                    }
                    if rows.isEmpty { Text("Lecture des processus…").foregroundStyle(.secondary).padding(20) }
                }
            }
        }
    }
}

final class NavigationState: ObservableObject {
    @Published var selected: Page = .overview
    @Published var settings = false
    @Published var appearance = UserDefaults.standard.integer(forKey: "appearance") { didSet { UserDefaults.standard.set(appearance, forKey: "appearance") } }

}

struct Dashboard: View {
    @ObservedObject var monitor: Monitor
    @StateObject private var navigation = NavigationState()
    var body: some View {
        HStack(spacing: 0) {
            sidebar
            Divider()
            VStack(spacing: 0) {
                HStack {
                    Text(navigation.selected.rawValue).font(.system(size: 18, weight: .semibold))
                    Spacer()
                    Button { monitor.exportReport() } label: { Label("Exporter", systemImage: "square.and.arrow.up") }.help("Créer un rapport HTML interactif et exportable en CSV")
                    if monitor.paused { Text("En pause").font(.caption).foregroundStyle(.secondary) }
                    Button { navigation.settings.toggle() } label: { Image(systemName: "gearshape").font(.system(size: 17)).foregroundStyle(.secondary) }.buttonStyle(.plain).help("Réglages").popover(isPresented: $navigation.settings) { settingsPanel }
                    Toggle("Mesures en direct", isOn: Binding(get: { !monitor.paused }, set: { if $0 == monitor.paused { monitor.togglePause() } })).labelsHidden().toggleStyle(.switch).tint(violet).help("Activer ou suspendre les mesures")
                }.padding(.horizontal, 24).frame(height: 68)
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) { pageContent }.padding(16).frame(maxWidth: .infinity)
                }.id(navigation.selected)
            }.background(Color(nsColor: .windowBackgroundColor))
        }.frame(minWidth: 900, minHeight: 640).preferredColorScheme(navigation.appearance == 0 ? nil : navigation.appearance == 1 ? .light : .dark).tint(violet)
    }
    var sidebar: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 8) { Image(systemName: "waveform.path.ecg").foregroundStyle(violet); Text("Pulse").fontWeight(.semibold) }.font(.system(size: 15)).padding(.horizontal, 15).frame(height: 58)
            ForEach(Page.allCases, id: \.self) { page in
                Button { navigation.selected = page } label: {
                    HStack(spacing: 12) { Image(systemName: page.icon).frame(width: 21); Text(page.rawValue).fontWeight(navigation.selected == page ? .semibold : .regular).lineLimit(1).minimumScaleFactor(0.85); Spacer(minLength: 0) }.font(.system(size: 14)).padding(.horizontal, 12).frame(height: 37).foregroundStyle(navigation.selected == page ? .white : Color.primary).background(navigation.selected == page ? violet : .clear, in: RoundedRectangle(cornerRadius: 6))
                }.buttonStyle(.plain).accessibilityIdentifier("nav-\(page.rawValue)")
            }
            Spacer()
            Text("LOCAL · EN TEMPS RÉEL").font(.system(size: 9, weight: .medium)).tracking(1).foregroundStyle(.tertiary).padding(.horizontal, 12)
            HStack(spacing: 22) {
                Button { navigation.settings.toggle() } label: { Image(systemName: "gearshape") }.help("Réglages")
                Button { monitor.togglePause() } label: { Image(systemName: monitor.paused ? "play.fill" : "pause.fill") }.help(monitor.paused ? "Reprendre" : "Mettre en pause")
                Spacer()
                Button { NSApp.terminate(nil) } label: { Image(systemName: "power") }.help("Quitter Pulse")
            }.buttonStyle(.plain).font(.system(size: 17)).foregroundStyle(.secondary).padding(12)
        }.padding(8).frame(width: 190).background(Color(nsColor: .underPageBackgroundColor))
    }
    var settingsPanel: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Réglages de Pulse").font(.headline)
            Picker("Apparence", selection: $navigation.appearance) { Text("Système").tag(0); Text("Claire").tag(1); Text("Sombre").tag(2) }

            Picker("Actualisation", selection: $monitor.interval) { Text("1 seconde").tag(1.0); Text("2 secondes").tag(2.0); Text("5 secondes").tag(5.0) }
            Text("Historique : 10 minutes\nProcessus : toutes les 5 secondes\nMesures locales, sans envoi de données.").font(.caption).foregroundStyle(.secondary)
        }.padding(20).frame(width: 300)
    }
    @ViewBuilder var pageContent: some View {
        switch navigation.selected {
        case .overview: overview
        case .cpu: cpuPage
        case .gpu: gpuPage
        case .ram: ramPage
        case .disk: diskPage
        case .network: networkPage
        case .battery: batteryPage
        case .sensors: sensorsPage
        case .clock: clockPage
        }
    }
    @ViewBuilder var overview: some View {
        VStack(spacing: 15) {
            Image(systemName: "laptopcomputer").font(.system(size: 100, weight: .ultraLight)).foregroundStyle(LinearGradient(colors: [violet, blue], startPoint: .top, endPoint: .bottom)).padding(.top, 14)
            Text(Host.current().localizedName ?? "Mon Mac").font(.system(size: 24, weight: .semibold))
            Text("macOS \(ProcessInfo.processInfo.operatingSystemVersion.majorVersion).\(ProcessInfo.processInfo.operatingSystemVersion.minorVersion).\(ProcessInfo.processInfo.operatingSystemVersion.patchVersion)").foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity).padding(.bottom, 12)
        Panel {
            VStack(spacing: 13) {
                InfoRow(label: "Processeur", value: "\(monitor.cpuName)\n\(Hardware.coreDescription)")
                Divider(); InfoRow(label: "Mémoire", value: gb(monitor.total))
                Divider(); InfoRow(label: "Graphiques", value: "\(monitor.gpuName)\(monitor.extra.gpuCores.map { " · \($0) cœurs" } ?? "")")
                Divider(); InfoRow(label: "Disque", value: "\(monitor.extra.diskName) · \(gb(monitor.extra.diskTotal))")
                Divider(); InfoRow(label: "Identifiant du modèle", value: sysString("hw.model"))
            }
        }
        HStack(spacing: 12) {
            overviewMetric("Processeur", monitor.cpu, blue, .cpu)
            overviewMetric("RAM", monitor.ram, .pink, .ram)
            overviewMetric("GPU", monitor.gpu, violet, .gpu)
        }
        Panel { InfoRow(label: "Temps de fonctionnement", value: "\(Int(ProcessInfo.processInfo.systemUptime) / 3600) heures et \(Int(ProcessInfo.processInfo.systemUptime) / 60 % 60) minutes") }
    }
    func overviewMetric(_ title: String, _ value: Double?, _ color: Color, _ page: Page) -> some View {
        Button { navigation.selected = page } label: { Panel { HStack { Ring(value: value, color: color); VStack(alignment: .leading, spacing: 6) { Text(title).fontWeight(.semibold); Text("Voir les détails").font(.caption).foregroundStyle(.secondary) } } } }.buttonStyle(.plain)
    }
    @ViewBuilder var cpuPage: some View {
        Panel {
            HStack(spacing: 22) {
                Ring(value: monitor.cpu)
                VStack(spacing: 15) {
                    HStack { Text(monitor.cpuName); Spacer(); Text("\(ProcessInfo.processInfo.processorCount) cœurs").foregroundStyle(.secondary) }
                    UsageBar(pieces: [(monitor.cpuSystem, .red), (monitor.cpuUser, blue)])
                    HStack { legend("Système", "\(percent(monitor.cpuSystem)) %", .red); Spacer(); legend("Utilisateur", "\(percent(monitor.cpuUser)) %", blue); Spacer(); legend("Inactif", "\(percent(monitor.cpu.map { 100 - $0 })) %", .gray) }
                }
            }
        }
        Block(title: "Historique d’utilisation") { HistoryChart(samples: monitor.history, key: \.cpu) }
        Block(title: "Charge par cœur") {
            Panel {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                    ForEach(Array(monitor.cores.enumerated()), id: \.offset) { index, value in Meter(title: "Cœur \(index + 1)", value: value, color: .cyan) }
                }
            }
        }
        HStack(alignment: .top, spacing: 12) {
            Block(title: "Charge moyenne") { Panel { VStack(spacing: 8) { ForEach(0..<3) { index in InfoRow(label: ["1 minute", "5 minutes", "15 minutes"][index], value: String(format: "%.2f", monitor.extra.load[index])) } } } }
            Block(title: "Informations") { Panel { VStack(spacing: 8) { InfoRow(label: "Architecture", value: Hardware.architecture); InfoRow(label: "Cœurs physiques", value: "\(sysInt("hw.physicalcpu"))"); InfoRow(label: "Fréquence instantanée", value: "Non disponible") } } }
        }
        ProcessTable(monitor: monitor)
    }
    @ViewBuilder var gpuPage: some View {
        Panel {
            VStack(alignment: .leading, spacing: 18) {
                Text("\(monitor.gpuName)\(monitor.extra.gpuCores.map { " (\($0) cœurs)" } ?? "")")
                HStack(spacing: 20) { Meter(title: "Utilisation du GPU", value: monitor.gpu); Meter(title: "Utilisation du Tiler", value: monitor.extra.tiler) }
                HStack(spacing: 20) { Meter(title: "Utilisation du rendu", value: monitor.extra.renderer); InfoRow(label: "Mémoire GPU partagée", value: monitor.extra.gpuMemory.map(bytes) ?? "Indisponible") }
            }
        }
        Block(title: "Historique d’utilisation du GPU") { HistoryChart(samples: monitor.history, key: \.gpu) }
        HStack(alignment: .top, spacing: 12) {
            Block(title: "Historique du rendu") { HistoryChart(samples: monitor.history, key: \.renderer) }
            Block(title: "Historique du Tiler") { HistoryChart(samples: monitor.history, key: \.tiler) }
        }
        Panel { VStack(spacing: 10) { InfoRow(label: "Utilisation de l’ANE", value: "Non exposée par cette source"); InfoRow(label: "FPS globaux et GPU par processus", value: "Non disponibles") } }
    }
    @ViewBuilder var ramPage: some View {
        Panel {
            HStack(spacing: 22) {
                Ring(value: monitor.ram, color: .pink)
                VStack(spacing: 14) {
                    HStack { Text("Utilisée : \(gb(monitor.used))"); Spacer(); Text("Total : \(gb(monitor.total))") }
                    UsageBar(pieces: [(max(0, monitor.used - monitor.wired - monitor.compressed) / monitor.total * 100, .pink), (monitor.wired / monitor.total * 100, Color(white: 0.35)), (monitor.compressed / monitor.total * 100, .orange)])
                    HStack { legend("Applications", gb(max(0, monitor.used - monitor.wired - monitor.compressed)), .pink); Spacer(); legend("Résidente", gb(monitor.wired), .gray) }
                    HStack { legend("Compressée", gb(monitor.compressed), .orange); Spacer(); legend("Disponible / cache", gb(monitor.total - monitor.used), .green) }
                }
            }
        }
        HistoryChart(samples: monitor.history, key: \.ram)
        HStack(alignment: .top, spacing: 12) {
            Block(title: "Mémoire utilisée") { Panel { VStack(spacing: 12) { InfoRow(label: "Applications", value: gb(max(0, monitor.used - monitor.wired - monitor.compressed)), color: .pink); InfoRow(label: "Résidente (wired)", value: gb(monitor.wired), color: .gray); InfoRow(label: "Compressée", value: gb(monitor.compressed), color: .orange) } } }
            Block(title: "Swap") { Panel { VStack(alignment: .leading, spacing: 12) { Text(bytes(monitor.swap)).font(.system(size: 30, weight: .medium)); Text("Espace disque utilisé pour la mémoire virtuelle.").font(.caption).foregroundStyle(.secondary) } } }
        }
        ProcessTable(monitor: monitor, memory: true)
    }
    var diskPage: some View {
        let utilization = monitor.extra.diskTotal > 0 ? (1 - monitor.extra.diskFree / monitor.extra.diskTotal) * 100 : 0
        return VStack(alignment: .leading, spacing: 20) {
            Panel { HStack(spacing: 22) { Ring(value: utilization); VStack(spacing: 15) { HStack { Text(monitor.extra.diskName); Spacer(); Text(gb(monitor.extra.diskTotal)).foregroundStyle(.secondary) }; UsageBar(pieces: [(utilization, blue)]); HStack { legend("Utilisé", gb(monitor.extra.diskTotal - monitor.extra.diskFree), blue); Spacer(); legend("Libre", gb(monitor.extra.diskFree), .gray) } } } }
            HStack(alignment: .top, spacing: 12) {
                Block(title: "Historique de lecture") { throughput(\.read, blue) }
                Block(title: "Historique d’écriture") { throughput(\.write, .red) }
            }
            HStack(alignment: .top, spacing: 12) {
                Block(title: "Débits · tous les disques physiques") { Panel { VStack(spacing: 12) { InfoRow(label: "Lecture", value: rate(monitor.extra.diskRead), color: blue); InfoRow(label: "Écriture", value: rate(monitor.extra.diskWrite), color: .red); InfoRow(label: "Lectures depuis le démarrage", value: gb(monitor.extra.totalRead)); InfoRow(label: "Écritures depuis le démarrage", value: gb(monitor.extra.totalWrite)) } } }
                Block(title: "Volume système") { Panel { VStack(spacing: 12) { InfoRow(label: "Capacité", value: gb(monitor.extra.diskTotal)); InfoRow(label: "Espace libre", value: gb(monitor.extra.diskFree)); InfoRow(label: "Santé SMART et température", value: "Non disponibles"); Text("L’espace libre APFS peut différer du stockage disponible affiché par macOS, qui inclut l’espace purgeable.").font(.caption).foregroundStyle(.secondary) } } }
            }
        }
    }
    @ViewBuilder var networkPage: some View {
        Panel { HStack { Spacer(); networkNumber("Téléchargement", monitor.extra.download, blue); Spacer(); networkNumber("Envoi", monitor.extra.upload, .red); Spacer() }.padding(10) }
        HStack(alignment: .top, spacing: 12) {
            Block(title: "Historique des téléchargements") { throughput(\.download, blue) }
            Block(title: "Historique des envois") { throughput(\.upload, .red) }
        }
        HStack(alignment: .top, spacing: 12) {
            Block(title: "Interface") { Panel { VStack(spacing: 14) { InfoRow(label: "Interfaces actives", value: monitor.extra.interfaces.joined(separator: ", ")); InfoRow(label: "État du lien local", value: monitor.extra.networkUp ? "ACTIF" : "INACTIF", color: monitor.extra.networkUp ? .green : .red); InfoRow(label: "Périmètre", value: "Interfaces physiques en*") } } }
            Block(title: "Adresses locales") { Panel { VStack(alignment: .leading, spacing: 14) { ForEach(monitor.extra.addresses, id: \.self) { Text($0).textSelection(.enabled) }; if monitor.extra.addresses.isEmpty { Text("Aucune adresse IPv4") }; Text("La disponibilité d’Internet n’est pas testée.").font(.caption).foregroundStyle(.secondary) } } }
        }
    }
    @ViewBuilder var batteryPage: some View {
        Panel { HStack(spacing: 24) { Ring(value: monitor.extra.battery, color: .green); VStack(alignment: .leading, spacing: 10) { Text(monitor.extra.battery == nil ? "Aucune batterie détectée" : "\(percent(monitor.extra.battery)) % de charge").font(.title2); Text(monitor.extra.charging ? "Recharge en cours" : monitor.extra.powerSource).foregroundStyle(.secondary) } } }
        Panel { VStack(spacing: 12) { InfoRow(label: "Source d’alimentation", value: monitor.extra.powerSource); InfoRow(label: "Recharge", value: monitor.extra.charging ? "Oui" : "Non"); InfoRow(label: "Mode économie d’énergie", value: ProcessInfo.processInfo.isLowPowerModeEnabled ? "Activé" : "Désactivé") } }
    }
    var thermal: String {
        switch ProcessInfo.processInfo.thermalState { case .nominal: return "Normal"; case .fair: return "Modéré"; case .serious: return "Élevé"; case .critical: return "Critique"; @unknown default: return "Inconnu" }
    }
    @ViewBuilder var sensorsPage: some View {
        Panel { VStack(spacing: 14) { InfoRow(label: "État thermique macOS", value: thermal, color: .orange); InfoRow(label: "Températures CPU / GPU", value: "Non disponibles"); InfoRow(label: "Vitesse des ventilateurs", value: "Non disponible") } }
        Text("L’état thermique est fourni par macOS. Les températures détaillées et les ventilateurs nécessitent une prise en charge spécifique des capteurs de ce modèle.").font(.callout).foregroundStyle(.secondary).padding(5)
    }
    var clockPage: some View {
        TimelineView(.periodic(from: .now, by: 1)) { context in
            Panel { VStack(spacing: 18) { Text(context.date, format: .dateTime.hour().minute().second()).font(.system(size: 64, weight: .light, design: .rounded)).monospacedDigit(); Text(context.date, format: .dateTime.weekday(.wide).day().month(.wide).year()).font(.title3); Text(TimeZone.current.identifier).foregroundStyle(.secondary) }.frame(maxWidth: .infinity).padding(40) }
        }
    }
    func throughput(_ key: KeyPath<Sample, Double?>, _ color: Color) -> some View {
        HistoryChart(samples: monitor.history, key: key, color: color, scale: max(1024, monitor.history.compactMap { $0[keyPath: key] }.max() ?? 1024), percentAxis: false)
    }
    func legend(_ label: String, _ value: String, _ color: Color) -> some View {
        HStack(spacing: 4) { RoundedRectangle(cornerRadius: 2).fill(color).frame(width: 10, height: 10); Text("\(label) :").foregroundStyle(.secondary); Text(value).monospacedDigit() }.font(.system(size: 12))
    }
    func networkNumber(_ label: String, _ value: Double?, _ color: Color) -> some View {
        VStack(spacing: 7) { Text(rate(value)).font(.system(size: 30, weight: .regular)).monospacedDigit(); HStack { RoundedRectangle(cornerRadius: 3).fill(color).frame(width: 12, height: 12); Text(label).foregroundStyle(.secondary) } }
    }
}
