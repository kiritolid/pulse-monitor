'use strict';
// Standalone, offline report. No dependencies or remote resources.
const samples = payload.samples;
const chart = document.querySelector('#chart');
const select = document.querySelector('#metric');
const tip = document.querySelector('#tooltip');
document.querySelector('#specs').textContent = `${payload.model} · ${payload.cpu} · ${payload.architecture} · ${payload.memory} de RAM`;
function draw() {
  const ratio = window.devicePixelRatio || 1;
  const width = chart.clientWidth, height = 300;
  chart.width = width * ratio; chart.height = height * ratio;
  const ctx = chart.getContext('2d'); ctx.scale(ratio, ratio);
  ctx.font = '12px system-ui'; ctx.fillStyle = '#888';
  for (let p = 0; p <= 100; p += 25) {
    const y = 10 + (100 - p) * 2.6;
    ctx.fillText(`${p}%`, 0, y + 4); ctx.strokeStyle = '#eee';
    ctx.beginPath(); ctx.moveTo(40, y); ctx.lineTo(width, y); ctx.stroke();
  }
  const values = samples.map(s => s[select.value]).filter(Number.isFinite);
  document.querySelector('#summary').textContent = values.length ? `${values.length} mesures · Moyenne ${(values.reduce((a,b) => a+b,0)/values.length).toFixed(1)} % · Pic ${Math.max(...values).toFixed(1)} %` : 'Aucune mesure disponible';
  ctx.strokeStyle = '#903e99'; ctx.lineWidth = 2; ctx.beginPath();
  let drawing = false;
  samples.forEach((s,i) => {
    const v = s[select.value]; if (!Number.isFinite(v)) { drawing = false; return; }
    const x = xFor(s.time, width), y = 10 + (100-v)*2.6;
    if (drawing) ctx.lineTo(x,y); else ctx.moveTo(x,y); drawing = true;
  }); ctx.stroke();
}
function xFor(time, width) {
  const start = samples[0]?.time || 0, end = samples.at(-1)?.time || start;
  return 40 + (time-start)/Math.max(1,end-start)*(width-45);
}
chart.addEventListener('mousemove', event => {
  if (!samples.length) return;
  const x = event.clientX-chart.getBoundingClientRect().left;
  const s = samples.reduce((best,s) => Math.abs(xFor(s.time,chart.clientWidth)-x) < Math.abs(xFor(best.time,chart.clientWidth)-x) ? s : best);
  const v=s[select.value]; tip.textContent=`${new Date(s.time).toLocaleTimeString('fr-FR')} · ${Number.isFinite(v) ? v.toFixed(1)+' %' : 'Indisponible'}`;
});
select.addEventListener('change', draw);
window.addEventListener('resize', draw);
document.querySelector('#csv').addEventListener('click', () => {
  const csv = ['date,cpu_pct,ram_pct,gpu_pct', ...samples.map(s => [new Date(s.time).toISOString(),s.cpu,s.ram,s.gpu].join(','))].join('\n');
  const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
  const a=document.createElement('a');a.href=url;a.download='pulse-mesures.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
});
draw();
